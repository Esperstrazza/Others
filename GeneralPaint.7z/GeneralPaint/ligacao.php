﻿<?php 

	//ligação à base de dados
	$host = 'localhost';  //ou 127.0.0.1
	$user = 'root';      //utilizador base de dados
	$pass = '';         //pass de acesso à base de dados
	$db = 'gp';        //base de dados 

	// conexão e seleção do banco de dados
	$con = mysqli_connect($host, $user, $pass, $db);

?>