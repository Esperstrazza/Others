<?php 
$id= $_POST['codUser'];
$nome= $_POST['username'];
$email= $_POST['email'];
$login= $_POST['user'];
$pass= $_POST['pass'];



$cx = mysqli_connect("127.0.0.1", "root");
$db = mysqli_select_db($cx, "gp");

$sql = mysqli_query($cx, "UPDATE user SET nome= '$nome', email= '$email', login= '$login', password= '$pass' Where codUser='$id'") or die(mysqli_error($cx));

header("Location: ./mostraUtilizadores.php");
die();

?>  