<div id="footer">
	<div id="mapaMenu">
		

			<div id="mapa1">
				<iframe src="https://www.google.com/maps/	embed?pb=!4v1542996278906!6m8!1m7!1seDlU1hPoGQd0uDhdrIUYwg!2m2!1d39.23341680251885!2d-8.686464555270101!3f231.8709824352662!4f6.164173742349021!5f0.7820865974627469" width="300" height="300" frameborder="0" style="border:0;"  allowfullscreen></iframe>
			</div>

	<div id="infor">
			 <div class="btn-group">
			 	<form>
			 		 <button formaction="inserirProdutos.php"><?php echo $lang['admin']; ?></button>
			 	</form>
			 	

</div>
</div>
		</div>
			<div id="mapa2">
				

				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3090.4214171337026!2d-8.688940985689442!3d39.23330433468085!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd18ee6ddc50c5d3%3A0x534d7a6da473c77d!2sISLA+-+Instituto+Superior+de+Gest%C3%A3o+e+Administra%C3%A7%C3%A3o!5e0!3m2!1spt-PT!2spt!4v1542996573794" width="300" height="300" frameborder="0" style="border:0;" allowfullscreen></iframe>

		</div>

</div>


</body>
</html>