<?php include('cabecalho.php');
?>

<?php

if(isset($_GET['id'])){
	$id =$_GET['id'] ;
		if($id==1){ 

 ?>

	<script type="text/javascript">
alert("<?php echo $lang['errlog']; ?> "); 
</script>
<?php   }}
?>

<?php
if(isset($_SESSION['logado'])){
	header("location: produtos.php");
	session_destroy();
}


?>

	<form name="flogin" method="POST" action="valida.php" id="flogin">
		<h1><?php echo $lang['restrict']; ?></h1>
		<p><input type="text" name="user" placeholder=<?php echo $lang['insert1']; ?> class="dados"></p>
		<p><input type="password" name="pass" placeholder=<?php echo $lang['insert2']; ?> class="dados"></p>
		<p id="pbtn"><input type="submit" name="btn" id="btn" value=<?php echo $lang['access']; ?>></p>
		<p id="pbtns"><input type="reset" name="limpa" id="btns" value=<?php echo $lang['cle']; ?>></p>
		<p class="centro"><?php echo $lang['noaccount']; ?></p>
		<p class="centro"><a href="registo.php" id="link"><?php echo $lang['click']; ?></a></p>
	</form>



<?php include('rodape.php');
?>