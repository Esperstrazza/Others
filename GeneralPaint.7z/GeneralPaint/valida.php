﻿<?php

require("ligacao.php");

session_start();

$utilizador = $_POST['user'];
$password = $_POST['pass'];

$sql = mysqli_query($con, "SELECT * FROM user Where login='$utilizador' and password='$password'") or die(
	mysqli_error($con));
	echo mysqli_num_rows($sql);
	if(mysqli_num_rows($sql) > 0 ){
		$row = $sql->fetch_assoc();
		$_SESSION['login'] = $utilizador; 
		$_SESSION['senha'] = $password;

		if ($utilizador == "admin") {
			$_SESSION['logado']=true;
			header('location:inserirProdutos.php');
		}

		
		elseif ($utilizador != "admin") {
			$_SESSION['logado1']=true;
		 	header('location:Produtos.php?user='.$utilizador);
		 } 
	}
	 else{

		session_destroy();
	    header('location:login.php?id=1');
   
	}
		
	

?>