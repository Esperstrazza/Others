<?php

$name = $_POST['username'];
$mail = $_POST['email'];
$utilizador = $_POST['user'];
$password = $_POST['pass'];
$rePasswords = $_POST['re-pass'];


echo "<p>nome:".$name."</p>";
echo "<p>email:".$mail."</p>";
echo "<p>Utilizador:".$utilizador."</p>";
echo "<p>Password:".$password."</p>";
echo "<p>Password:".$rePasswords."</p>";


?>
