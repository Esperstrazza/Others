<?php include('cabecalho.php');
?>


<form id="flogin" method="POST" action="ligaDB.php" data-toggle="validator" role="form">

	<h1><?php echo $lang['fill2']; ?></h1>

	<div class="form-group">
		<p><label for="username" class="control-label"><?php echo $lang['insert4']; ?></label>
		<input name="username" class="dados" placeholder=<?php echo $lang['insert4']; ?> type="text" required></p>
	</div>

	<div class="form-group">
		<p><label for="email" class="control-label"><?php echo $lang['insert3']; ?></label></p>
		<p><input name="email" class="dados" placeholder=<?php echo $lang['insert3']; ?> type="email" required>
		<div class="help-block with-error"></div></p>
	</div>

	<div class="form-group">
		<p><label for="user"  class="control-label" ><?php echo $lang['insert1']; ?></label></p>
		<p><input name="user" class="dados" placeholder=<?php echo $lang['insert1']; ?> type="text" required></div></p>
	</div>

	<div class="form-group">
		<p><label for="pass" class="control-label"><?php echo $lang['insert2']; ?></label></p>
		<p><input type="password" id='pass' class="dados" name="pass" placeholder=<?php echo $lang['insert2']; ?> data-minlength="6" required>
		<span class="help-block"><?php echo $lang['notequal1']; ?></span></p>
	</div>

	<div class="form-group">
		<p><label for="inputConfirm" class="control-label"><?php echo $lang['insert2']; ?></label></p>
		<p><input type="password" class="dados" name="re-pass" placeholder=<?php echo $lang['insert2']; ?>
		data-match="#pass" required data-match-error=<?php echo $lang['notequal2']; ?> >
		</div></p>
	</div>

	<div class="form-group">
		<div class="checkbox">
		<p><label>
			<input type="checkbox" required> <?php echo $lang['check']; ?> 
		</label>
		<div class="help-block with-error"></div>
	</div></p>
	</div>
	<div class ="form-group">

		<p id="pbtn"><input type="submit" name="btn" id="btn" value=<?php echo $lang['regist']; ?>></p>
		<p id="pbtns"><input type="reset" name="limpa" id="btns" value=<?php echo $lang['cle']; ?>></p>
		<p class="centro"><?php echo $lang['fill1']; ?>
		<a href="login.php" id="link"><?php echo $lang['click']; ?></a></p>

</div>
</form>

<script src="js/validator.min.js"></script>


<?php include('rodape.php');
?>