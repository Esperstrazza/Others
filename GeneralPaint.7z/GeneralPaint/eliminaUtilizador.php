<?php 

$var = $_GET['id'];

$cx = mysqli_connect("127.0.0.1", "root");
$db = mysqli_select_db($cx, "gp");


$sql = mysqli_query($cx, "DELETE FROM user Where codUser=$var") or die(
	mysqli_error($cx));

	header('Location: mostraUtilizadores.php');
?>