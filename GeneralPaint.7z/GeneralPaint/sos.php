<?php 


$nome = $_GET['nome'];
$preco = $_GET['preco'];
$imagem = $_GET['imagem']; 


$cx2 = mysqli_connect("127.0.0.1", "root");
$db2 = mysqli_select_db($cx2, "gp");
$sql2 = mysqli_query($cx2, "INSERT INTO produtos (nome, preco, imagem) VALUES('$nome','$preco','$imagem')") or die(
	mysqli_error($cx2));

echo $nome;
echo $preco;
echo $imagem;

header("Location: ./produtos.php");
die();

?>


