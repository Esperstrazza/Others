<?php include('cabecalhoLogin.php');?>

<?php

    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

if(isset($_GET['sair'])){
	header("location: login.php");
	session_destroy();
}


?>

<div id="t02">
<?php require("ligacao.php");
	$sql = mysqli_query($con, "SELECT * FROM produtos") or die(
	mysqli_error($con));
	echo "<ul>";
	while($ln = mysqli_fetch_assoc($sql)){
	
		
		echo "<li>";
		echo '<h3>'.$ln['nome'].'</h3> <br/>';
		echo 'Preço: '.number_format($ln['preco'],2,',','.').'€/L<br/>';
		echo '<img src="img/'.$ln['imagem'].'"/><br/>';
		echo '<a href="carrinho.php?acao=add&id='.$ln['id'].'">Comprar</a>';
		echo '<br/> <hr>';
		echo "</li>";
		


	}
	echo "</ul>";
?>
</div>


<?php include('rodapeLogin.php');?>