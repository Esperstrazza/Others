<?php include('cabecalhoLogin.php');?>


<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
if(!isset($_SESSION['logado'])){
	header("location: produtos.php");
	session_destroy();
}
if(isset($_GET['sair'])){
	header("location: login.php");
	session_destroy();
}

?>

<!--<form id="flogin" method="GET" action="ligaPR.php" data-toggle="validator" role="form">-->

	<form id="flogin" method="GET" action="sos.php" >

	<h1><?php echo $lang['fill3']; ?></h1>

	<div class="form-group">
		<p><label for="nome" class="control-label"><?php echo $lang['insertpro1']; ?></label></p>
		<p><input name="nome" class="dados" placeholder=<?php echo $lang['insertpro1']; ?> type="text" required></p>
	</div>

	<div class="form-group">
		<p><label for="preco" class="control-label"><?php echo $lang['insertpro2']; ?></label></p>
		<p><input name="preco" class="dados" placeholder=<?php echo $lang['insertpro2']; ?> type="text" required></p>
	</div>

	<div class="form-group">
		<p><label for="imagem"  class="control-label" ><?php echo $lang['insertpro3']; ?></label></p>
		<p><input name="imagem" class="dados" placeholder=<?php echo $lang['insertpro3']; ?> type="text" required></p>
	</div>

	<div class ="form-group">
		<p id="pbtn"><input type="submit" name="btn" id="btn" value=<?php echo $lang['fill3']; ?>></p>
		<p id="pbtns"><input type="reset" name="limpa" id="btns" value=<?php echo $lang['cle']; ?>></p>
	</div>

</form>

<?php include('rodapeAdmin.php');
?>