<?php include('cabecalhoLogin.php');
?>

<?php 
$id= $_GET['codUser'];
$nome= $_GET['nome'];
$email= $_GET['email'];
$login= $_GET['login'];
$pass= $_GET['password'];
 ?>
<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
if(!isset($_SESSION['logado'])){
	header("location: login.php");
	session_destroy();
}
if(isset($_GET['sair'])){
	header("location: login.php");
	session_destroy();
}

?>

<form id="flogin" method="POST" action="updateUser.php" data-toggle="validator" role="form">

	<div class="form-group">
		<p><label for="codUser" hidden class="control-label"><?php echo $lang['insert5']; ?></label>
		<input name="codUser" class="dados"  value=<?php echo $id; ?> type="text" hidden ></p>
	</div>

	<div class="form-group">
		<p><label for="username" class="control-label"><?php echo $lang['insert4']; ?></label>
		<input name="username" class="dados" placeholder=<?php echo $lang['insert4']; ?> type="text" required></p>
	</div>

	<div class="form-group">
		<p><label for="email" class="control-label"><?php echo $lang['insert3']; ?></label></p>
		<p><input name="email" class="dados" placeholder=<?php echo $lang['insert3']; ?> type="email" required>
		<div class="help-block with-error"></div></p>
	</div>
	
	<div class="form-group">
		<p><label for="user"  class="control-label" ><?php echo $lang['insert1']; ?></label></p>
		<p><input name="user" class="dados" placeholder=<?php echo $lang['insert1']; ?> type="text" required></div></p>
	</div>

	<div class="form-group">
		<p><label for="pass" class="control-label"><?php echo $lang['insert2']; ?></label></p>
		<p><input type="password" id='pass' class="dados" name="pass" placeholder=<?php echo $lang['insert2']; ?> data-minlength="6" required>
		<span class="help-block"><?php echo $lang['notequal1']; ?></span></p>
	</div>

	<div class="form-group">
		<p><label for="inputConfirm" class="control-label"><?php echo $lang['insert2']; ?></label></p>
		<p><input type="password" class="dados" name="re-pass" placeholder=<?php echo $lang['insert2']; ?>
		data-match="#pass" required data-match-error=<?php echo $lang['notequal2']; ?> >
		</div></p>
	</div>


		<p id="pbtn"><input type="submit" name="btn" id="btn" value=<?php echo $lang['edi']; ?>></p>
		<p id="pbtns"><input type="reset" name="limpa" id="btns" value=<?php echo $lang['cle']; ?>></p>


</div>
</form>


<script src="js/validator.min.js"></script>


<?php include('rodapeAdmin.php');
?>