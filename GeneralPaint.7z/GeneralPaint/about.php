<?php include('cabecalho.php');?>


<div id="t0about">
	<?php echo $lang['abouttext']; ?>
	<br>
	<img src="img/img_colormap.jpg">
</div>


<?php include('rodape.php');?>