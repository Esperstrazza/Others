<?php include('cabecalhoLogin.php');?>

<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
if(!isset($_SESSION['logado'])){
	header("location: login.php");
	session_destroy();
}
if(isset($_GET['sair'])){
	header("location: login.php");
	session_destroy();
}

?>

<div id="t03">
<table>
		<tr>
			<th><?php echo $lang['insert5']; ?></th>
			<th><?php echo $lang['insert4']; ?></th>
			<th><?php echo $lang['insert1']; ?></th>
			<th><?php echo $lang['insert2']; ?></th>
			<th><?php echo $lang['insert3']; ?></th>
			<th><?php echo $lang['edi']; ?></th>
			<th><?php echo $lang['rem']; ?></th>
		</tr>
		
<?php
$cx = mysqli_connect("127.0.0.1", "root");
$db = mysqli_select_db($cx, "gp");
$sql = mysqli_query($cx, "SELECT * FROM user") or die(
	mysqli_error($cx));


While($aux = mysqli_fetch_assoc($sql))
{
		echo"<tr>";
			echo"<td>$aux[codUser]</td>";
			echo"<td>$aux[nome]</td>";
			echo"<td>$aux[login]</td>";
			echo"<td>$aux[password]</td>";
			echo"<td>$aux[email]</td>";
			echo "<td><a href=editaUtilizadores.php?codUser=$aux[codUser]&nome=$aux[nome]&login=$aux[login]&password=$aux[password]&email=$aux[email]>Click </a></td>";
			echo "<td><a href=eliminaUtilizador.php?id=$aux[codUser]>Click </a></td>";
		echo"</tr>";

}
?>
</table>
</div>


<?php include('rodapeAdmin.php');
?>