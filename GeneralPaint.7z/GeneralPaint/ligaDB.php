<?php

$name = $_POST['username'];
$utilizador = $_POST['user'];
$password = $_POST['pass'];
$mail = $_POST['email'];


$cx = mysqli_connect("127.0.0.1", "root");
$db = mysqli_select_db($cx, "gp");
$sql = mysqli_query($cx, "INSERT INTO user (nome,login,password,email) VALUES('$name','$utilizador','$password','$mail')") or die(
	mysqli_error($cx));




header("Location: ./login.php");
die();

?>