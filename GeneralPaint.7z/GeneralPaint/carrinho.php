﻿<?php include('cabecalhoLogin.php');?>

<?php
$total = 0;
		 
		
		if(!isset($_SESSION['carrinho'])){
			//$total=0;
			$_SESSION['carrinho'] = array();
		}
		//adicionar produto
		
		if(isset($_GET['acao'])){
			//adicionar carrinho
			if($_GET['acao']=='add'){
				$id = intval($_GET['id']);
				if(!isset($_SESSION['carrinho'][$id])){
					$_SESSION['carrinho'][$id] = 1;
				}else{  //caso já exista
					$_SESSION['carrinho'][$id] += 1;
				}
			}
			//remover carrinho
			if($_GET['acao']=='del'){
				$id = intval($_GET['id']);
				if(isset($_SESSION['carrinho'][$id])){
					unset($_SESSION['carrinho'][$id]);
				}
			}
			
			//alterar quantidade
			if($_GET['acao']=='up'){
				if(is_array($_POST['prod'])){
					foreach($_POST['prod'] as $id => $qtd){
						$id = intval($id);
						$qtd = intval($qtd);
						if(!empty($qtd) || $qtd <> 0){
							$_SESSION['carrinho'][$id] = $qtd;
						}else{
							unset($_SESSION['carrinho'][$id]);
						}
					}
				}
			}
			
		}
	//	print_r($_SESSION['carrinho']);  //para mostrar como está a ficar o carrinho
?>


<?php

    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

if(isset($_GET['sair'])){
	header("location: login.php");
	session_destroy();
}
?>

	<table id='t01'>
	<caption><h3><?php echo $lang['carcom']; ?></h3></caption>
		<thead>
			<tr>
				<th width="244"><?php echo $lang['prod']; ?></th>
				<th width="80"><?php echo $lang['quan']; ?></th>
				<th width="90"><?php echo $lang['pre']; ?></th>
				<th width="100">Sub Total</th>
				<th width="64"><?php echo $lang['rem']; ?></th>
			</tr>
		</thead>
	<form action="?acao=up" method="POST">
		<tfoot>
			<tr>
				<td colspan="5"><input type="submit" value=<?php echo $lang['upd']; ?>></td>
			</tr>
			<tr>
				<td colspan="5"><a href="produtos.php"/><?php echo $lang['con']; ?> </a></td>
			</tr>	
		</tfoot>
		<tbody>
				<?php
						if(count($_SESSION['carrinho'])==0){
							echo '<tr><td colspan="5" >Não tem produtos adicionados ao carrinho</td></tr>';
							
						}else{
							require("ligacao.php");
							foreach($_SESSION['carrinho'] as $id => $qtd){
								$sql = mysqli_query($con, "SELECT * FROM produtos WHERE id='$id'") or die(mysqli_error($con));
								
								$ln = mysqli_fetch_assoc($sql);
								
								$nome   = $ln['nome'];
								$p = floatval($ln['preco']);
								$preco  = number_format($p,2,'.',' ');
								$sub    = floatval($preco)*floatval($qtd);
								
								//para mostrar o total do custo dos produtos presentes no carrinho
								$total+=$sub;   
								
							echo '<tr>
										<td>'.$nome.'</td>
										<td><input type="text" size="3" name="prod['.$id.']" value="'.$qtd.'"/></td>
										<td>'.$preco.'</td>
										<td>'.$sub.'</td>
										<td><a href="?acao=del&id='.$id.'">Remove</a></td>
								</tr>';		
								
								
								
							}
							//$totalf=number_format($total,2,',','.');
							echo '<tr>
									<td colspan="4">Total</td>
									<td colspan="4">'.$total.'€</td>
								</tr>';
							
						}
				?>
	
		</tbody>
		
	</form>
	</table>
	
<?php include('rodapeLogin.php');?>